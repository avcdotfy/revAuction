<footer class="main-footer">
    Copyright © 2023 <strong><?php echo e(env('APP_NAME')); ?></strong><strong> | <a href="https://www.dotfy.co" target="_blank">AVC
            Dotfy
            LLP</a></strong><br /> All rights reserved.
</footer>
<?php /**PATH C:\xampp\htdocs\revAuction\resources\views/vendor/partials/footer.blade.php ENDPATH**/ ?>