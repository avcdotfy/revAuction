    <!-- ./wrapper -->

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>    

    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- DataTables -->
    
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    
<?php /**PATH C:\xampp\htdocs\revAuction\resources\views/vendor/partials/scripts.blade.php ENDPATH**/ ?>