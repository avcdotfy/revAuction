

<?php $__env->startSection('main_section'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h4>Create Category </h4>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <div id="ContentPlaceHolder1_div_nr" class="row">
                            <form action="<?php echo e(route('category.store')); ?>" method="post" id="categoryForm">
                                <?php echo csrf_field(); ?>
                                <?php echo $__env->make('admin.partials.category-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>
                <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('validations/category-validator.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#item_time_trigger').on('change', function(e) {
                if (e.target.value == 0) {
                    $('#last_minute_time_to_increment').prop('disabled', true);
                } else {
                    $('#last_minute_time_to_increment').prop('disabled', false);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revAuction\resources\views/admin/pages/catalog/category/create.blade.php ENDPATH**/ ?>