<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HelpsupportController extends Controller
{
    //

    function create()
    {
        return view('admin.pages.helpSupport.help-support');
    }
    function store()
    {
        
    }
}
