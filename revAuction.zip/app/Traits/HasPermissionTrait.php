<?php

namespace App\Traits;

use App\Models\Permission;

trait HasPermissionTrait
{
}
