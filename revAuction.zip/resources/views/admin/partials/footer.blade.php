<footer class="main-footer">
    Copyright © 2023 <strong> {{ env('APP_NAME') }}</strong><strong> | <a href="https://www.dotfy.co" target="_blank">AVC
            Dotfy
            LLP</a></strong><br /> All rights reserved.
</footer>
