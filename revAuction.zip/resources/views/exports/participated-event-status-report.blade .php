<table>
    <tr>
        <td>Event ID</td>
        <td>Event Title</td>
        <td>Company Name</td>
        <td>Username</td>
        <td>Item Name</td>
        <td>UoM</td>
        <td>Region Name</td>
        <td>Base Price</td>
        <td>Item Unit</td>
        <td>Item Unit Details</td>
        <td>Item Status</td>
        <td>Quantity</td>
        <td>Last Bidding Price</td>
        <td>Capping Price</td>
        <td>Accept Quantity</td>
        <td>Accept Amount</td>
        <td>Admin Decision</td>
        <td>Admin Remarks</td>
    </tr>
    <tr>
        <td>ST021105202315</td>
        <td>Event for Steel : Opening Date &amp; Time 11-05-2023 08:08 AM (IST) and Closing Date &amp; Time 11-05-2023
            08:20 AM (IST)</td>
        <td>Zenith Lab Ltd.</td>
        <td>bidder3</td>
        <td>Stainless steel (S02)</td>
        <td>Ton</td>
        <td>PAN India</td>
        <td>25000</td>
        <td>200</td>
        <td>1 Unit = 1 Ton</td>
        <td>L1</td>
        <td>200</td>
        <td>0</td>
        <td></td>
        <td>200</td>
        <td>0.00</td>
        <td>Accepted</td>
        <td>Well accepted</td>
    </tr>

</table>
